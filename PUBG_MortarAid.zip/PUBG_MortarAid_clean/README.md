# PUBG 지도 거리 및 박격포 실험 계산기

## 현재 범위

Python 3 + Tkinter 데스크톱 MVP입니다. 이미지에서 플레이어/핑은 사용자가 지정하고, 100m 격자 간격은 자동 추정 또는 A/B 수동 보정으로 수평 직선거리를 구합니다. 음영으로 H를 참고 추정할 수 있지만 박격포 설정값은 별도 근거로 확인한 H를 입력했을 때만 계산합니다. 계산된 거리 설정값은 **실험 검증 전**입니다.

자동 아이콘·핑 검출, PUBG 맵과 스크린샷 자동 정합, 게임 내 실제 고도(m) raster, 자동 고도조회는 아직 구현되지 않았습니다. 음영은 실제 고도 데이터가 아니라 실험용 상대 높이 추정에만 사용합니다.

## 실행

```powershell
cd <outputs folder>
python -m pip install -r requirements.txt
python pubg_map_distance.py
```

1. 스크린샷을 엽니다. 파일 열기 버튼을 쓰거나 이미지 파일을 앱 화면으로 끌어 놓을 수 있습니다.
2. 내 위치와 목표 핑 중심을 직접 찍습니다.
3. `격자 자동 인식`을 눌러 밝은 수평·수직 반복선의 간격을 추정합니다. 검출 후보를 이미지와 대조해 확인한 뒤 계산합니다. 실패하거나 두 축 간격이 맞지 않으면 A/B 수동 보정을 사용합니다.
4. 수평 직선거리를 계산합니다.
5. 신뢰할 수 있는 별도 근거로 H를 알고 있을 때만 H(m)를 입력하고 다시 계산합니다. 부호는 `목표 고도 - 발사 고도`입니다.

자동 격자 검출은 이미지 밝기 프로파일에서 주기 간격을 찾는 보수적 방법입니다. 반복 점수는 성공 확률이 아닙니다. 축이 회전했거나 격자선이 흐리거나 지도 UI/텍스처가 반복적으로 나타나면 실패 또는 오검출할 수 있으므로, 실제 격자와 맞는지 확인하고 애매하면 A/B를 사용하세요.

지도를 마우스 휠 또는 `+`/`-` 키로 확대·축소하고 오른쪽 마우스 드래그로 이동할 수 있습니다. 확대해 클릭해도 원본 이미지 좌표로 변환됩니다.

H 입력란을 비워 두면 `models/shading.py`가 시작점과 목표점 사이의 이미지 음영으로 H를 추정해 참고용으로 표시하지만, 박격포 설정값 계산에는 사용하지 않습니다. 수동 H를 입력해야 설정값을 계산합니다. 음영 모델은 선형화한 밝기에 Lambertian 반사, 균일 albedo, 사용자가 입력한 단일 광원 방향을 가정합니다. 한 장의 음영에서 shape/albedo/light가 원천적으로 모호하므로, 최소 기울기·광원 방향 정렬 prior를 둔 단순 1차원 근사만 사용합니다. 이는 [Barron & Malik의 단일 이미지 shape/albedo/illumination 연구](https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/reconstruction/BarronMalikCVPR2012.pdf)의 문제 설정과 불확실성을 참고한 자체 단순화 구현이며 논문 알고리즘의 재현이 아닙니다.

기본 음영 가정은 방위각 315°, 고도각 45°, albedo 0.9이며, 검증된 PUBG 조명 값이 아닙니다. 지도 텍스처, 패치 색상, 그림자, 광원 방향, UI 겹침에 민감합니다. 사용자가 제공한 Erangel 사례(L=257.0m, H=+32.8m, 보고 설정값=273.4m)에서 화면 지점을 대략 선택해 시험했을 때 음영 H는 약 +212.7m였습니다. 이 값은 알려진 H와 크게 달라 설정값 계산에서 음영을 제외했습니다. 지점을 대략 선택한 결과이므로 정식 정확도 검증으로 취급하지 않습니다. 계산식은 같은 입력에서 263.6m를 예측해 보고된 273.4m와 약 -9.8m 차이가 있습니다. 기준 사례는 `tests/reference_observations.csv`에 기록했고, 해당 입력 근처에서 비교만 표시합니다. 한 사례의 오차를 다른 거리/고도에 일반화하거나 보정값으로 더하지 않습니다.

## 탄도 모델

`models/ballistics.py`는 [Iamnotphage/MortarAid4PUBG](https://github.com/Iamnotphage/MortarAid4PUBG)의 공개 README에 적힌 식을 재구현합니다.

```text
t = H / L
R = (L + t * (M - sqrt(M² - 2*L*M*t - L²))) / (1 + t²)
```

- `L`: 지도에서 얻은 수평거리(m)
- `H`: 목표 고도 − 발사 고도(m), 양수는 목표가 높고 음수는 낮음
- `M`: 같은 높이에서의 최대 사거리 가정(m), 기본값 700
- `R`: 식이 반환하는 추정 설정 거리(m)

이상적 포물선 운동, 동일한 수평면 최대 사거리 `M=700m`, 고정 중력/초속 모델을 전제로 공개된 계산식입니다. 원본 README도 700m에서 45°라는 주장을 “정밀 테스트하지 않았다”고 적고, 실제 게임 탄도 상수 및 엔진 중력은 모른다고 명시합니다. 원본 코드의 시야각 보정은 viewport 중앙에서 화면 위쪽까지를 26.19°로 선형 변환하지만, 그 각도 보정의 게임 내 정확도 데이터는 제시하지 않습니다. 이 앱은 시야각 경로를 쓰지 않고 고도차 H를 별도 입력받습니다.

식의 판별식이 음수인 입력은 실수 해가 없으므로 계산하지 않습니다. 이 식은 게임의 거리 눈금 양자화, 탄체 저항/충돌, 포신 초기각 범위, 최소·최대 눈금 매핑을 모델링하거나 검증하지 않습니다. `R`을 확정 조준값으로 취급하지 마세요.

## 지형 고도 데이터

`models/terrain.py`는 일반적인 georeferenced 16-bit PNG height raster를 읽고 메타데이터로 보간하는 기반 모듈입니다. JSON은 다음 정보를 요구합니다.

```json
{
  "map_name": "map identifier",
  "world_width_m": 8160,
  "world_height_m": 8160,
  "elevation_m_per_code": 0.1,
  "elevation_offset_m": 0,
  "uncertainty_m": 5,
  "source": "dataset and version"
}
```

예시 수치는 형식 설명용일 뿐, PUBG에 사용할 값이 아닙니다. 특히 `elevation_m_per_code`, `elevation_offset_m`, 좌표 원점과 수평 extent는 해당 raster의 출처에서 확인해야 합니다. 이 모듈은 임의의 scale을 추정하지 않고, caller가 raster 픽셀 좌표계로 등록된 지도 좌표를 전달해야 합니다. 현재 UI에는 지도 좌표 정합 도구가 없어 실제 스크린샷 클릭에서 heightmap 좌표로 가는 완전한 end-to-end 연동은 되지 않습니다.

### 조사한 자료 및 사용 조건

- 사용자 제공 ZIP `MortarAid4PUBG-main`: GitHub 공개 프로젝트 [Iamnotphage/MortarAid4PUBG](https://github.com/Iamnotphage/MortarAid4PUBG), 문서의 작성자 표시 및 버전 태그는 확인되지 않음. 압축된 CHANGELOG에는 2026-04-17까지 기록이 있음. 파일 목록에서 LICENSE를 확인하지 못해 코드/이미지/데이터를 복사하거나 재배포하지 않았습니다. 여기서는 수식과 공개된 동작을 참고했습니다.
- [cgcostume/pubg-maps](https://github.com/cgcostume/pubg-maps): PUBG 게임 소스에서 높이/노멀 자료를 추출·조립하는 공개 스크립트입니다. README는 PAK이 AES 암호화되며 UE Viewer로 heightmap을 추출한다고 설명하고, 스크립트는 16-bit 높이 샘플을 보존한 PNG를 만듭니다. 저장소 파일 목록에 LICENSE가 없어 라이선스가 확인되지 않았습니다. 게임 자산을 추출하거나 이 저장소의 데이터를 앱에 번들하지 않았습니다.
- [PUBG 공식 telemetry 문서](https://documentation.pubg.com/en/telemetry-objects.html): telemetry Location의 X/Y/Z가 cm 단위이고 원점이 각 맵의 좌상단임을 설명하며 Erangel/Miramar 등 맵 X/Y 범위가 816,000cm임을 제시합니다. 이는 수평 맵 좌표 범위를 알려주지만 height raster의 16-bit 값을 게임 고도(m)로 바꾸는 스케일이나 스크린샷 정합점을 제공하지 않습니다.
- 공개 유도 자료의 700m/45° 경험 주장은 정밀 측정이 아니라고 원문이 표시합니다. 따라서 현재 탄도 결과는 검증 자료가 아니라 실험 가능한 가설입니다.
- 원문이 나열한 계산식 참고문헌: 绝地King-of-Mortar, “PUBG迫击炮开炮密位公式推导” (小黑盒, 2025-01-03, [원문 링크](https://api.xiaoheihe.cn/v3/bbs/app/api/web/share?link_id=b7a56f9c397c)); 一只黄小娥 ([Bilibili, 2024-10-03](https://www.bilibili.com/video/BV1Ub4VeyEFA/)); 一只黄小娥, 수동판 버전 이력 ([yzhxe.cn](https://www.yzhxe.cn/file-downloads/1/4), 원문 표기 2025-12-06). 첫 링크는 브라우징 도구에서 리디렉션 접근 오류, Bilibili는 접근 제한, 이력 페이지는 일반 소개 화면만 보여 본문 확인이 제한됐습니다. ZIP 내 README와 계산기 소스는 직접 확인했습니다.

### 데이터 제작 및 정합 상태

해당 공개 terrain 저장소의 절차는 설치된 PUBG 게임 자산에서 UE Viewer로 map heightmap을 뽑고, 타일 스크립트로 16-bit raster를 stitch하는 것입니다. 자료는 게임 버전/자산 구조에 따라 달라질 수 있다고 명시합니다. heightmap PNG의 16-bit code를 게임 Z 미터로 바꾸는 변환 상수, 각 스크린샷의 맵 수평 좌표 대응점, 저장소 데이터 라이선스는 확인되지 않았습니다. 이에 따라 게임 지형의 고도와 H는 자동 산출하지 않습니다. raw sample interpolation은 synthetic data tests로만 검증했습니다.

## 검증

```powershell
python -m unittest discover -s tests -v
```

자동 테스트는 수평거리 3사례, 합성 격자의 spacing·실패·축 불일치, 탄도식의 같은 높이/오르막/내리막/비실수 입력, synthetic 16-bit raster 보간 및 범위 검사를 수행합니다. 테스트 통과는 계산 구현만 확인하며 실제 스크린샷 인식 정확도나 PUBG 탄도·게임 지형을 검증하지 않습니다.

## 실제 게임 검증 절차

`tests/manual_ballistics_template.csv`에 다음을 기록합니다.

1. 사격장 등 안전한 연습 조건에서 게임 빌드/날짜와 맵, 테스트 위치를 기록합니다.
2. 같은 높이, 목표가 높은 경우, 낮은 경우를 포함해 근거리와 원거리 표본을 수집합니다.
3. 실제 수평거리와 발사/목표 고도차를 독립적으로 확인합니다. 고도가 독립적으로 확인되지 않으면 해당 행의 H를 미상으로 두고 계산 정확도 지표에서 제외합니다.
4. 각 조건에서 계산 예측값과 실제 눈금 설정, 여러 발의 명중/착탄 오차를 기록합니다. 반복 횟수와 측정 불확실성도 남깁니다.
5. 식 보정에 쓴 사례와 분리된 검증 사례를 보관합니다. 충분한 착탄 오차 수치가 쌓인 뒤에만 MAE/RMSE를 계산하고, 명중/빗나감만으로 식 전체의 정확성을 입증하지 않습니다.

테스트용 기준 입력과 예측값은 공개된 식 구현의 회귀 확인일 뿐 실제 게임 관측 결과가 아닙니다.
