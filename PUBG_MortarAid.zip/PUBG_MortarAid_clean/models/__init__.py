"""Independent terrain and experimental ballistics models."""
