"""Conservative automatic spacing estimate for bright, axis-aligned map grids."""

from dataclasses import dataclass
import math

import numpy as np


class GridDetectionError(ValueError):
    pass


@dataclass(frozen=True)
class GridSpacing:
    horizontal_px: float  # distance between vertical grid lines
    vertical_px: float  # distance between horizontal grid lines
    confidence_x: float
    confidence_y: float


def _profile(gray, axis):
    # Grid lines are expected to be bright and to span a substantial portion
    # of the map. Counting bright pixels suppresses isolated bright labels.
    bright = gray >= 190
    return bright.mean(axis=axis).astype(np.float64)


def _correlation_profile(values):
    values = values - values.mean()
    n = len(values)
    size = 1 << (2 * n - 1).bit_length()
    spectrum = np.fft.rfft(values, n=size)
    autocorr = np.fft.irfft(spectrum * np.conjugate(spectrum), n=size)[:n]
    overlap = np.arange(n, 0, -1, dtype=np.float64)
    autocorr = autocorr / overlap
    if autocorr[0] <= 1e-12:
        raise GridDetectionError("Image has no usable bright-line variation")
    return autocorr / autocorr[0]


def _spacing(gray, axis):
    profile = _profile(gray, axis)
    # Smooth single-pixel noise but preserve typical map grid widths.
    kernel = np.ones(3, dtype=np.float64) / 3
    profile = np.convolve(profile, kernel, mode="same")
    corr = _correlation_profile(profile)
    low = 20
    high = min(500, len(profile) // 3)
    if high <= low:
        raise GridDetectionError("Image is too small to estimate grid spacing")
    # Reward a candidate whose multiples also repeat: this favors the base
    # interval over a line-spacing harmonic.
    candidates = np.arange(low, high + 1)
    score = corr[candidates].copy()
    for multiplier, weight in ((2, 0.5), (3, 0.25)):
        valid = candidates * multiplier < len(corr)
        score[valid] += weight * corr[candidates[valid] * multiplier]
    i = int(np.argmax(score))
    lag = int(candidates[i])
    confidence = float(corr[lag])
    # Refine the peak location with a three-point parabolic fit.
    if 1 <= lag < len(corr) - 1:
        left, mid, right = corr[lag - 1], corr[lag], corr[lag + 1]
        denom = left - 2 * mid + right
        if abs(denom) > 1e-12:
            lag += float(0.5 * (left - right) / denom)
    return lag, confidence


def detect_grid_spacing(image_rgb, *, min_confidence=0.08, max_axis_mismatch=0.20):
    """Estimate 100m grid pixel spacing from an RGB array.

    This deliberately supports only bright, near-horizontal/vertical grids.
    Ambiguous images raise GridDetectionError so callers can fall back to
    manual calibration instead of silently inventing a scale.
    """
    image = np.asarray(image_rgb)
    if image.ndim != 3 or image.shape[2] < 3 or min(image.shape[:2]) < 80:
        raise GridDetectionError("Expected a color map image at least 80x80 pixels")
    rgb = image[..., :3].astype(np.float64)
    gray = 0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]
    # Remove outer UI edges which can create false repeating peaks.
    y0, y1 = int(gray.shape[0] * 0.06), int(gray.shape[0] * 0.94)
    x0, x1 = int(gray.shape[1] * 0.06), int(gray.shape[1] * 0.94)
    crop = gray[y0:y1, x0:x1]
    vertical_lines_px, confidence_x = _spacing(crop, axis=0)
    horizontal_lines_px, confidence_y = _spacing(crop, axis=1)
    if min(confidence_x, confidence_y) < min_confidence:
        raise GridDetectionError(
            f"Grid pattern is weak (x={confidence_x:.2f}, y={confidence_y:.2f}); use A/B manual calibration"
        )
    mismatch = abs(vertical_lines_px - horizontal_lines_px) / max(vertical_lines_px, horizontal_lines_px)
    if mismatch > max_axis_mismatch:
        raise GridDetectionError(
            f"Horizontal/vertical spacing disagrees by {mismatch:.0%}; image may be rotated, distorted, or ambiguous"
        )
    return GridSpacing(vertical_lines_px, horizontal_lines_px, confidence_x, confidence_y)
