"""Experimental one-dimensional shape-from-shading height-difference estimate.

Assumptions: grayscale hillshade is Lambertian, albedo is constant, the light
direction is known, and the minimum-magnitude slope is preferred. A single
image cannot uniquely determine shape, albedo, and illumination; this function
is explicitly an exploratory estimate, not a terrain measurement.
"""

from dataclasses import dataclass
import math

import numpy as np


class ShadingEstimateError(ValueError):
    pass


@dataclass(frozen=True)
class ShadingEstimate:
    height_delta_m: float
    samples_used: int
    median_fit_error: float
    assumptions: str = "Lambertian, uniform albedo, supplied light, smooth/minimum-slope prior"
    validation_status: str = "실험 검증 전 · 정량 오차 검증 불가"


def _linear_luminance(rgb):
    srgb = np.asarray(rgb, dtype=np.float64) / 255.0
    linear = np.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)
    return 0.2126 * linear[..., 0] + 0.7152 * linear[..., 1] + 0.0722 * linear[..., 2]


def _slope_from_intensity(intensity, albedo, light_h, light_z):
    observed = intensity / albedo
    if observed <= 0.015 or observed > 1.02:
        raise ShadingEstimateError("Path crosses clipped shadow/highlight or violates the albedo assumption")
    observed = min(observed, 1.0)
    # Under n=(-grad_x,-grad_y,1)/|...|, constrain the ambiguous 2D
    # gradient to the horizontal light direction and choose the flattest fit.
    candidates = np.linspace(-4.0, 4.0, 4001)
    predicted = (light_z - candidates * light_h) / np.sqrt(1 + candidates * candidates)
    errors = (predicted - observed) ** 2
    best = np.flatnonzero(errors <= errors.min() + 1e-12)
    idx = int(best[np.argmin(np.abs(candidates[best]))])
    if errors[idx] > 0.015 ** 2:
        raise ShadingEstimateError("Observed shade is inconsistent with the supplied light/albedo model")
    return float(candidates[idx]), float(math.sqrt(errors[idx]))


def estimate_height_delta(image_rgb, start_xy_px, target_xy_px, pixels_per_100m,
                          light_azimuth_deg=315.0, light_elevation_deg=45.0,
                          albedo=0.9, samples=64):
    """Estimate signed target-minus-start height (m) along the straight route.

    Azimuth is clockwise from image-up/north. The horizontal map scale must be
    independently calibrated. This simplified single-profile method is highly
    sensitive to lighting, map styling, texture, shadows, and albedo.
    """
    image = np.asarray(image_rgb)
    if image.ndim != 3 or image.shape[2] < 3:
        raise ShadingEstimateError("Expected an RGB image")
    vals = (pixels_per_100m, light_azimuth_deg, light_elevation_deg, albedo)
    if not all(math.isfinite(float(v)) for v in vals):
        raise ShadingEstimateError("Scale and lighting/albedo inputs must be finite")
    if pixels_per_100m <= 0 or not (0 < light_elevation_deg < 90) or not (0.05 <= albedo <= 1):
        raise ShadingEstimateError("Scale must be positive; light elevation must be 0–90°; albedo must be 0.05–1")
    height_px, width_px = image.shape[:2]
    x0, y0 = map(float, start_xy_px)
    x1, y1 = map(float, target_xy_px)
    if any(not math.isfinite(v) for v in (x0, y0, x1, y1)):
        raise ShadingEstimateError("Point coordinates must be finite")
    if not (0 <= x0 < width_px and 0 <= x1 < width_px and 0 <= y0 < height_px and 0 <= y1 < height_px):
        raise ShadingEstimateError("A selected point lies outside the image")
    route_px = math.hypot(x1 - x0, y1 - y0)
    if route_px < 2:
        raise ShadingEstimateError("Selected points are too close for shading analysis")

    az = math.radians(light_azimuth_deg)
    el = math.radians(light_elevation_deg)
    light_x, light_y = math.sin(az), -math.cos(az)
    light_h, light_z = math.cos(el), math.sin(el)
    luminance = _linear_luminance(image[..., :3])
    count = max(8, min(int(samples), int(route_px) + 1))
    slopes, fit_errors = [], []
    for t in np.linspace(0.05, 0.95, count):
        x, y = x0 + t * (x1 - x0), y0 + t * (y1 - y0)
        cx, cy = int(round(x)), int(round(y))
        patch = luminance[max(0, cy - 2):min(height_px, cy + 3), max(0, cx - 2):min(width_px, cx + 3)]
        intensity = float(np.median(patch))
        try:
            slope, error = _slope_from_intensity(intensity, albedo, light_h, light_z)
        except ShadingEstimateError:
            continue
        slopes.append(slope)
        fit_errors.append(error)

    if len(slopes) < max(8, int(count * 0.7)):
        raise ShadingEstimateError("Too much of the route is inconsistent with the assumed shading model")

    delta_x_m = (x1 - x0) * 100.0 / pixels_per_100m
    delta_y_m = (y1 - y0) * 100.0 / pixels_per_100m
    # Least-norm prior constrains local slope to the light's horizontal direction.
    relief = float(np.median(slopes))
    height_delta = relief * (delta_x_m * light_x + delta_y_m * light_y)
    return ShadingEstimate(height_delta, len(slopes), float(np.median(fit_errors)))
