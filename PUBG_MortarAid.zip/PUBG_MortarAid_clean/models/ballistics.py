"""Experimental implementation of the public MortarAid4PUBG formula.

This is a community hypothesis, not a validated PUBG trajectory model.
Distances are metres; height_delta_m is target elevation minus firing elevation.
"""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class BallisticEstimate:
    setting_m: float
    model: str = "community-projectile-v1"
    validation_status: str = "실험 검증 전"


class BallisticDomainError(ValueError):
    """Inputs are outside the real-valued domain of the community formula."""


def estimate_setting(horizontal_m: float, height_delta_m: float,
                     maximum_level_range_m: float = 700.0) -> BallisticEstimate:
    """Return the community formula's setting estimate, without claiming validity.

    Implements R=(L+t*(M-sqrt(M²-2*L*M*t-L²)))/(1+t²),
    where t=H/L. The source assumes ideal projectile motion, maps the level
    maximum range to M=700m, and does not establish PUBG's actual physics.
    """
    vals = (horizontal_m, height_delta_m, maximum_level_range_m)
    if not all(math.isfinite(v) for v in vals):
        raise BallisticDomainError("Inputs must be finite numbers")
    if horizontal_m <= 0 or maximum_level_range_m <= 0:
        raise BallisticDomainError("Horizontal distance and maximum range must be positive")

    t = height_delta_m / horizontal_m
    radicand = maximum_level_range_m ** 2 - 2 * horizontal_m * maximum_level_range_m * t - horizontal_m ** 2
    tolerance = 1e-12 * maximum_level_range_m ** 2
    if radicand < -tolerance:
        raise BallisticDomainError("No real-valued solution under the community model")
    radicand = max(0.0, radicand)
    setting = (horizontal_m + t * (maximum_level_range_m - math.sqrt(radicand))) / (1 + t * t)
    if not math.isfinite(setting) or setting <= 0:
        raise BallisticDomainError("Community formula returned an invalid setting")
    return BallisticEstimate(setting_m=setting)
