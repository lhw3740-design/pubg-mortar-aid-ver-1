"""Experimental implementation of a published MortarAid4PUBG formula.

This is an unvalidated hypothesis, not a verified PUBG trajectory model.
Distances are metres; height_delta_m is target elevation minus firing elevation.
"""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class BallisticEstimate:
    setting_m: float
    model: str = "projectile-v1"
    validation_status: str = "실험 검증 전"


class BallisticDomainError(ValueError):
    """Inputs are outside the real-valued domain of this formula."""


def estimate_setting(horizontal_m: float, height_delta_m: float,
                     maximum_level_range_m: float = 700.0) -> BallisticEstimate:
    """Return the formula's setting estimate, without claiming validity.

    Implements R=(L+t*(M-sqrt(M²-2*L*M*t-L²)))/(1+t²),
    where t=H/L. The source assumes ideal projectile motion, maps the level
    maximum range to M=700m, and does not establish PUBG's actual physics.
    """
    vals = (horizontal_m, height_delta_m, maximum_level_range_m)
    if not all(math.isfinite(v) for v in vals):
        raise BallisticDomainError("Inputs must be finite numbers")
    if horizontal_m <= 0 or maximum_level_range_m <= 0:
        raise BallisticDomainError("Horizontal distance and maximum range must be positive")

    t = height_delta_m / horizontal_m
    radicand = maximum_level_range_m ** 2 - 2 * horizontal_m * maximum_level_range_m * t - horizontal_m ** 2
    tolerance = 1e-12 * maximum_level_range_m ** 2
    if radicand < -tolerance:
        raise BallisticDomainError("현재 식의 입력 범위에서 실수 해를 구할 수 없습니다")
    radicand = max(0.0, radicand)
    setting = (horizontal_m + t * (maximum_level_range_m - math.sqrt(radicand))) / (1 + t * t)
    if not math.isfinite(setting) or setting <= 0:
        raise BallisticDomainError("계산식이 유효하지 않은 설정값을 반환했습니다")
    return BallisticEstimate(setting_m=setting)
