"""User-supplied, single-point in-game reference; not a generalized fit."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ReferenceCase:
    horizontal_m: float
    height_delta_m: float
    observed_setting_m: float
    map_name: str
    note: str


# User report for the attached Erangel screenshot. Hit/miss outcome was not given.
REFERENCE_CASES = (
    ReferenceCase(
        horizontal_m=257.0,
        height_delta_m=32.8,
        observed_setting_m=273.4,
        map_name="Erangel",
        note="사용자 제공 관측값; 명중 여부 미기록",
    ),
)


def find_matching_reference(horizontal_m: float, height_delta_m: float,
                            distance_tolerance_m: float = 0.5,
                            height_tolerance_m: float = 0.1):
    """Return a reference only for the same measured condition, never extrapolate."""
    matches = [
        case for case in REFERENCE_CASES
        if abs(horizontal_m - case.horizontal_m) <= distance_tolerance_m
        and abs(height_delta_m - case.height_delta_m) <= height_tolerance_m
    ]
    return matches[0] if len(matches) == 1 else None


def find_reference_near_distance(horizontal_m: float, distance_tolerance_m: float = 0.5):
    """Find a recorded observation at a similar horizontal range for diagnostics."""
    matches = [case for case in REFERENCE_CASES
               if abs(horizontal_m - case.horizontal_m) <= distance_tolerance_m]
    return matches[0] if len(matches) == 1 else None
