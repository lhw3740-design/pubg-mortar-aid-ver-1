"""Generic georeferenced 16-bit height-raster reader.

No PUBG raster, vertical scale, or screenshot-to-map registration is bundled.
Those values must come from a source and map-specific calibration the user can
verify; unknown vertical units are deliberately rejected.
"""

from dataclasses import dataclass
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image


class TerrainDataError(ValueError):
    pass


@dataclass(frozen=True)
class ElevationSample:
    elevation_m: float
    uncertainty_m: float | None
    source: str


class GeoreferencedHeightMap:
    """A north-up square or rectangular raster in a local metre coordinate system.

    JSON requires `map_name`, `world_width_m`, `world_height_m`,
    `elevation_m_per_code`, and `elevation_offset_m`; optional uncertainty_m.
    Image x=0,y=0 is the map's top-left. Coordinates are metres from that corner.
    """

    def __init__(self, raster_path, metadata_path):
        self.raster_path = Path(raster_path)
        self.metadata_path = Path(metadata_path)
        try:
            self.meta = json.loads(self.metadata_path.read_text(encoding="utf-8"))
            image = Image.open(self.raster_path)
            if image.mode not in ("I;16", "I;16L", "I;16B", "I"):
                raise TerrainDataError("Height raster must be a 16-bit integer PNG")
            self.data = np.asarray(image, dtype=np.float64)
        except (OSError, json.JSONDecodeError) as exc:
            raise TerrainDataError(f"Cannot read height raster/config: {exc}") from exc
        required = ("map_name", "world_width_m", "world_height_m", "elevation_m_per_code", "elevation_offset_m")
        if any(k not in self.meta for k in required):
            raise TerrainDataError("Metadata is missing required map extents or elevation conversion")
        if self.data.ndim != 2 or min(self.data.shape) < 2:
            raise TerrainDataError("Height raster must be a 2D image of at least 2x2 pixels")
        self.width_m = float(self.meta["world_width_m"])
        self.height_m = float(self.meta["world_height_m"])
        self.scale = float(self.meta["elevation_m_per_code"])
        self.offset = float(self.meta["elevation_offset_m"])
        if not all(math.isfinite(v) for v in (self.width_m, self.height_m, self.scale, self.offset)) or min(self.width_m, self.height_m, self.scale) <= 0:
            raise TerrainDataError("Map dimensions and elevation scale must be finite and positive")
        uncertainty = self.meta.get("uncertainty_m")
        self.uncertainty = None if uncertainty is None else float(uncertainty)
        if self.uncertainty is not None and (not math.isfinite(self.uncertainty) or self.uncertainty < 0):
            raise TerrainDataError("uncertainty_m must be a nonnegative finite value")

    def sample(self, x_m, y_m):
        """Bilinearly sample elevation in metres; reject outside or nodata samples."""
        x_m, y_m = float(x_m), float(y_m)
        if not math.isfinite(x_m) or not math.isfinite(y_m) or not (0 <= x_m <= self.width_m and 0 <= y_m <= self.height_m):
            raise TerrainDataError("Requested map coordinate lies outside the raster extent")
        height, width = self.data.shape
        px = x_m / self.width_m * (width - 1)
        py = y_m / self.height_m * (height - 1)
        x0, y0 = int(math.floor(px)), int(math.floor(py))
        x1, y1 = min(x0 + 1, width - 1), min(y0 + 1, height - 1)
        dx, dy = px - x0, py - y0
        vals = (self.data[y0, x0], self.data[y0, x1], self.data[y1, x0], self.data[y1, x1])
        nodata = self.meta.get("nodata_code")
        if not all(math.isfinite(v) for v in vals) or (nodata is not None and any(v == float(nodata) for v in vals)):
            raise TerrainDataError("Heightmap sample touches missing/nodata cells")
        a = vals[0] * (1 - dx) + vals[1] * dx
        b = vals[2] * (1 - dx) + vals[3] * dx
        code = a * (1 - dy) + b * dy
        return ElevationSample(code * self.scale + self.offset, self.uncertainty, str(self.meta.get("source", self.raster_path.name)))

    def height_delta(self, firing_xy_m, target_xy_m):
        firing = self.sample(*firing_xy_m)
        target = self.sample(*target_xy_m)
        return firing, target, target.elevation_m - firing.elevation_m
