import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

from PIL import Image, ImageTk
from models.ballistics import BallisticDomainError, estimate_setting
from models.grid import GridDetectionError, detect_grid_spacing
from models.reference_cases import find_matching_reference, find_reference_near_distance
from models.shading import ShadingEstimateError, estimate_height_delta

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
except ImportError:  # The file picker remains usable if drag/drop support is missing.
    DND_FILES = None
    TkinterDnD = None


def distance_meters(start, end, cal_a, cal_b, calibration_m):
    calibration_px = math.hypot(cal_a[0] - cal_b[0], cal_a[1] - cal_b[1])
    if calibration_px <= 0 or calibration_m <= 0:
        raise ValueError("Calibration must be positive")
    return math.hypot(start[0] - end[0], start[1] - end[1]) / calibration_px * calibration_m


class MortarMapApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PUBG 지도 거리 측정기")
        self.root.geometry("1100x780")
        self.image = None
        self.photo = None
        self.scale = 1.0
        self.offset = (0, 0)
        self.zoom_factor = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.player = None
        self.target = None
        self.cal_a = None
        self.cal_b = None
        self.grid_spacing = None
        self.mode = tk.StringVar(value="player")
        self.status = tk.StringVar(value="스크린샷을 열고 시작 지점과 목표 핑을 지정하세요.")
        self.result = tk.StringVar(value="수평거리: —")
        self.model_result = tk.StringVar(value="음영 기반 고도·보정값: —")
        self._build_ui()

    def _build_ui(self):
        bar = ttk.Frame(self.root, padding=8)
        bar.pack(fill="x")
        ttk.Button(bar, text="스크린샷 열기", command=self.open_image).pack(side="left")
        ttk.Label(bar, text="  클릭 모드:").pack(side="left")
        for label, value in (("내 위치", "player"), ("목표 핑", "target"), ("격자 기준점 A", "cal_a"), ("격자 기준점 B", "cal_b")):
            ttk.Radiobutton(bar, text=label, value=value, variable=self.mode).pack(side="left", padx=3)
        ttk.Label(bar, text="기준점 간 실제 거리(m):").pack(side="left", padx=(12, 3))
        self.cal_m = tk.StringVar(value="100")
        ttk.Entry(bar, textvariable=self.cal_m, width=8).pack(side="left")
        ttk.Button(bar, text="거리 계산", command=self.calculate).pack(side="left", padx=10)
        ttk.Button(bar, text="초기화", command=self.clear_points).pack(side="left")
        ttk.Button(bar, text="격자 자동 인식", command=self.auto_calibrate_grid).pack(side="left", padx=8)

        viewbar = ttk.Frame(self.root, padding=(8, 0, 8, 6))
        viewbar.pack(fill="x")
        ttk.Label(viewbar, text="보기:").pack(side="left")
        ttk.Button(viewbar, text="＋ 확대", command=lambda: self.zoom_by(1.25)).pack(side="left", padx=3)
        ttk.Button(viewbar, text="－ 축소", command=lambda: self.zoom_by(1 / 1.25)).pack(side="left", padx=3)
        ttk.Button(viewbar, text="화면 맞춤", command=self.reset_view).pack(side="left", padx=3)
        ttk.Label(viewbar, text="지도 위 마우스 휠 또는 + / - 키로 확대·축소 · 오른쪽 버튼 드래그로 이동 · 파일을 창에 끌어 놓아 열기").pack(side="left", padx=12)

        self.canvas = tk.Canvas(self.root, background="#202328", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=8)
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Configure>", lambda _e: self.draw())
        self.canvas.bind("<MouseWheel>", self.on_mouse_wheel)
        self.canvas.bind("<ButtonPress-3>", self.start_pan)
        self.canvas.bind("<B3-Motion>", self.pan_view)
        self.canvas.bind("<Enter>", lambda _e: self.canvas.focus_set())
        self.canvas.bind("<KeyPress-plus>", lambda _e: self.zoom_by(1.25))
        self.canvas.bind("<KeyPress-equal>", lambda _e: self.zoom_by(1.25))
        self.canvas.bind("<KeyPress-minus>", lambda _e: self.zoom_by(1 / 1.25))
        self.canvas.bind("<KeyPress-underscore>", lambda _e: self.zoom_by(1 / 1.25))
        if DND_FILES is not None:
            self.canvas.drop_target_register(DND_FILES)
            self.canvas.dnd_bind("<<Drop>>", self.on_drop)
        ttk.Label(self.root, textvariable=self.result, font=("Segoe UI", 13, "bold"), padding=(10, 8), wraplength=1050).pack(anchor="w", fill="x")
        model_bar = ttk.Frame(self.root, padding=(10, 2))
        model_bar.pack(fill="x")
        ttk.Label(model_bar, text="고도차 H (목표−발사, m; 비우면 음영 자동 추정·적용):").pack(side="left")
        self.height_delta = tk.StringVar(value="")
        ttk.Entry(model_bar, textvariable=self.height_delta, width=10).pack(side="left", padx=5)
        shade_bar = ttk.Frame(self.root, padding=(10, 2))
        shade_bar.pack(fill="x")
        ttk.Label(shade_bar, text="음영 가정 광원 방위각°:").pack(side="left")
        self.light_azimuth = tk.StringVar(value="315")
        ttk.Entry(shade_bar, textvariable=self.light_azimuth, width=6).pack(side="left", padx=(3, 8))
        ttk.Label(shade_bar, text="고도각°:").pack(side="left")
        self.light_elevation = tk.StringVar(value="45")
        ttk.Entry(shade_bar, textvariable=self.light_elevation, width=5).pack(side="left", padx=(3, 8))
        ttk.Label(shade_bar, text="반사율:").pack(side="left")
        self.albedo = tk.StringVar(value="0.9")
        ttk.Entry(shade_bar, textvariable=self.albedo, width=5).pack(side="left", padx=3)
        ttk.Label(self.root, text="H를 비우면 선택한 두 지점 사이 음영을 분석해 H를 추정하고 설정값 계산에 자동 적용합니다. 실제 고도와 큰 차이가 날 수 있는 실험 추정입니다. 별도 근거의 H를 입력하면 자동 추정을 덮어씁니다.", padding=(10, 2), foreground="#8b342c", wraplength=1050).pack(anchor="w")
        ttk.Label(self.root, textvariable=self.status, padding=(10, 7), wraplength=1000).pack(anchor="w")

    def open_image(self):
        path = filedialog.askopenfilename(title="PUBG 지도 스크린샷 선택", filetypes=[("이미지", "*.png *.jpg *.jpeg *.bmp *.webp"), ("모든 파일", "*.*")])
        if not path:
            return
        self.load_image(path)

    def on_drop(self, event):
        paths = self.root.tk.splitlist(event.data)
        if paths:
            self.load_image(paths[0])

    def load_image(self, path):
        try:
            self.image = Image.open(path).convert("RGB")
        except Exception as exc:
            messagebox.showerror("이미지를 열 수 없음", str(exc))
            return
        self.path = Path(path)
        self.player = self.target = self.cal_a = self.cal_b = None
        self.grid_spacing = None
        self.zoom_factor = 1.0
        self.pan_x = self.pan_y = 0.0
        self.status.set(f"{self.path.name} · {self.image.width}×{self.image.height}px · 이번 이미지에서 새로 보정하세요.")
        self.draw()

    def draw(self):
        self.canvas.delete("all")
        if self.image is None:
            self.canvas.create_text(25, 25, anchor="nw", fill="white", text="스크린샷을 열어주세요.")
            return
        cw, ch = max(self.canvas.winfo_width(), 1), max(self.canvas.winfo_height(), 1)
        self.scale = min(cw / self.image.width, ch / self.image.height) * self.zoom_factor
        w, h = round(self.image.width * self.scale), round(self.image.height * self.scale)
        self.offset = ((cw - w) / 2 + self.pan_x, (ch - h) / 2 + self.pan_y)
        view = self.image.resize((w, h), Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(view)
        ox, oy = self.offset
        self.canvas.create_image(ox, oy, image=self.photo, anchor="nw")
        def xy(p): return (ox + p[0] * self.scale, oy + p[1] * self.scale)
        points = [("player", self.player, "#ffe34f", "내 위치"), ("target", self.target, "#35d8ff", "목표 핑"), ("cal_a", self.cal_a, "#7dff7a", "A"), ("cal_b", self.cal_b, "#ff7dca", "B")]
        for _, p, color, label in points:
            if p:
                x, y = xy(p)
                r = 8
                self.canvas.create_oval(x-r, y-r, x+r, y+r, outline=color, width=3)
                self.canvas.create_text(x+11, y-12, anchor="w", fill=color, text=label)
        if self.player and self.target:
            x1,y1=xy(self.player); x2,y2=xy(self.target)
            self.canvas.create_line(x1,y1,x2,y2, fill="#ff4d4d", width=2)
        if self.cal_a and self.cal_b:
            x1,y1=xy(self.cal_a); x2,y2=xy(self.cal_b)
            self.canvas.create_line(x1,y1,x2,y2, fill="#7dff7a", width=2, dash=(5,3))

    def zoom_by(self, factor, anchor=None):
        if self.image is None:
            return
        old_scale = self.scale
        new_zoom = min(8.0, max(0.5, self.zoom_factor * factor))
        if abs(new_zoom - self.zoom_factor) < 1e-9:
            return
        cw, ch = max(self.canvas.winfo_width(), 1), max(self.canvas.winfo_height(), 1)
        if anchor is None:
            anchor = (cw / 2, ch / 2)
        ix = (anchor[0] - self.offset[0]) / old_scale
        iy = (anchor[1] - self.offset[1]) / old_scale
        self.zoom_factor = new_zoom
        base = min(cw / self.image.width, ch / self.image.height)
        new_scale = base * self.zoom_factor
        self.pan_x = anchor[0] - (cw - self.image.width * new_scale) / 2 - ix * new_scale
        self.pan_y = anchor[1] - (ch - self.image.height * new_scale) / 2 - iy * new_scale
        self.draw()

    def on_mouse_wheel(self, event):
        self.zoom_by(1.2 if event.delta > 0 else 1 / 1.2, (event.x, event.y))
        return "break"

    def start_pan(self, event):
        self.pan_start = (event.x, event.y, self.pan_x, self.pan_y)

    def pan_view(self, event):
        if not hasattr(self, "pan_start"):
            return
        x, y, pan_x, pan_y = self.pan_start
        self.pan_x = pan_x + event.x - x
        self.pan_y = pan_y + event.y - y
        self.draw()

    def reset_view(self):
        self.zoom_factor = 1.0
        self.pan_x = self.pan_y = 0.0
        self.draw()

    def on_click(self, event):
        if self.image is None:
            return
        ox, oy = self.offset
        x = (event.x - ox) / self.scale
        y = (event.y - oy) / self.scale
        if not (0 <= x < self.image.width and 0 <= y < self.image.height):
            return
        setattr(self, self.mode.get(), (x, y))
        if self.mode.get() in ("cal_a", "cal_b"):
            self.grid_spacing = None
        self.status.set(f"{self.mode.get()} 지점을 지정했습니다. 아이콘/핑 중심을 클릭하고, A와 B는 한 격자 간격(100m) 양 끝에 놓으세요.")
        self.draw()

    def auto_calibrate_grid(self):
        if self.image is None:
            messagebox.showinfo("이미지 필요", "먼저 PUBG 지도 스크린샷을 여세요.")
            return
        try:
            found = detect_grid_spacing(self.image)
        except GridDetectionError as exc:
            self.grid_spacing = None
            self.status.set(f"격자 자동 인식 실패: {exc}. A/B 수동 보정을 사용하세요.")
            return
        self.grid_spacing = found
        self.cal_a = self.cal_b = None
        self.status.set(
            f"격자 자동 보정 후보: 가로 {found.horizontal_px:.1f}px/100m, "
            f"세로 {found.vertical_px:.1f}px/100m · 반복 점수 "
            f"{found.confidence_x:.2f}/{found.confidence_y:.2f}. "
            "화면에서 격자와 맞는지 확인한 뒤 거리 계산을 누르세요."
        )
        self.draw()

    def calculate(self):
        if self.image is None or self.player is None or self.target is None:
            messagebox.showinfo("점 지정 필요", "이미지를 열고 내 위치와 목표 핑 중심을 클릭하세요.")
            return
        if self.grid_spacing is None and (self.cal_a is None or self.cal_b is None):
            messagebox.showinfo("축척 보정 필요", "격자선 한 칸의 양 끝점을 A와 B로 지정하세요.")
            return
        def dist(a,b): return math.hypot(a[0]-b[0], a[1]-b[1])
        if self.grid_spacing is not None:
            pixels = (self.grid_spacing.horizontal_px + self.grid_spacing.vertical_px) / 2
            meters = 100.0
            scale_note = f"자동 격자 {self.grid_spacing.horizontal_px:.1f}/{self.grid_spacing.vertical_px:.1f}px per 100m"
        else:
            try:
                meters = float(self.cal_m.get())
                if meters <= 0: raise ValueError()
            except ValueError:
                messagebox.showerror("잘못된 거리", "기준점 간 실제 거리는 0보다 큰 숫자여야 합니다.")
                return
            pixels = dist(self.cal_a, self.cal_b)
            if pixels < 2:
                messagebox.showerror("보정 실패", "기준점이 너무 가깝습니다. 더 넓은 격자 구간을 선택하세요.")
                return
            scale_note = f"수동 축척 {pixels:.1f}px / {meters:g}m"
        dpx = dist(self.player, self.target)
        value = dpx / pixels * meters
        horizontal_text = f"수평 직선거리 L: {value:.0f} m    ({scale_note}, 두 점 {dpx:.1f}px)"
        height_text = self.height_delta.get().strip()
        calculation_ok = False
        try:
            if not height_text:
                h_m = estimate_height_delta(
                    self.image, self.player, self.target,
                    pixels_per_100m=pixels * 100 / meters,
                    light_azimuth_deg=float(self.light_azimuth.get()),
                    light_elevation_deg=float(self.light_elevation.get()),
                    albedo=float(self.albedo.get()),
                ).height_delta_m
                height_source = "음영 자동 추정·적용"
            else:
                h_m = float(height_text)
                height_source = "수동 입력"
            estimate = estimate_setting(value, h_m)
            reference = find_matching_reference(value, h_m) if height_text else None
            self.model_result.set(
                f"H {h_m:+.1f} m ({height_source}) · 보정 설정값 {estimate.setting_m:.0f} m · 실험 검증 전 추정"
            )
            reference_text = ""
            if reference is not None:
                residual = estimate.setting_m - reference.observed_setting_m
                reference_text = f"    |    이 조건의 관측 설정값: {reference.observed_setting_m:.1f} m (식 예측 오차 {residual:+.1f} m; 단일 사례, 일반 보정 미적용)"
            if not height_text:
                nearby = find_reference_near_distance(value)
                if nearby is not None:
                    h_error = h_m - nearby.height_delta_m
                    reference_text = f"    |    같은 거리 기준 사례 H {nearby.height_delta_m:+.1f} m 대비 음영 차이 {h_error:+.1f} m (단일 사례 경고)"
            self.result.set(f"{horizontal_text}    |    고도차 H: {h_m:+.1f} m ({height_source})    |    박격포 설정값 예측: {estimate.setting_m:.1f} m · 실험 검증 전{reference_text}")
            calculation_ok = True
        except (ValueError, BallisticDomainError, ShadingEstimateError) as exc:
            self.model_result.set(f"음영/탄도 계산 불가 — {exc}")
            self.result.set(f"{horizontal_text}    |    음영 고도차 / 박격포 보정값 계산 불가: {exc}")
        if not calculation_ok:
            self.status.set("음영 또는 탄도 계산이 불가능했습니다. 입력값과 선택 지점을 확인하세요.")
        elif height_text:
            self.status.set("수동 H를 탄도식에 적용했습니다. 거리 설정값은 실험 검증 전 추정이며 클릭·축척 오차가 포함됩니다.")
        else:
            self.status.set("음영에서 추정한 H를 설정값 계산에 자동 적용했습니다. 실제 광원·재질·지형 고도를 모르는 상태의 실험 추정이므로 결과 오차가 클 수 있습니다.")
        self.draw()

    def clear_points(self):
        self.player = self.target = self.cal_a = self.cal_b = None
        self.grid_spacing = None
        self.result.set("수평거리: —")
        self.model_result.set("음영 기반 고도·보정값: —")
        self.status.set("지점과 보정을 초기화했습니다. 현재 이미지에서 다시 지정하세요.")
        self.draw()


if __name__ == "__main__":
    root = TkinterDnD.Tk() if TkinterDnD is not None else tk.Tk()
    app = MortarMapApp(root)
    root.mainloop()



