@echo off
setlocal
cd /d "%~dp0"
set "LOG=%~dp0setup.log"
>"%LOG%" echo PUBG Map Distance Tool setup log
>>"%LOG%" echo Started: %DATE% %TIME%
where py >>"%LOG%" 2>&1
if errorlevel 1 goto :no_python
if not exist ".venv\Scripts\python.exe" (
  echo Creating the app's private Python environment...
  py -3 -m venv .venv >>"%LOG%" 2>&1
  if errorlevel 1 goto :failed
)
echo Installing Pillow and NumPy. This may take a few minutes on first run...
.venv\Scripts\python.exe -m pip install -r requirements.txt >>"%LOG%" 2>&1
if errorlevel 1 goto :failed
echo Starting the app...
.venv\Scripts\python.exe -u pubg_map_distance.py >>"%LOG%" 2>&1
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" goto :failed
echo The app closed normally. Setup log: %LOG%
pause
exit /b 0
:no_python
echo Python 3.10+ or the Python Launcher (py) was not found.
echo Install Python from https://www.python.org/downloads/windows/ and enable the Python Launcher option.
echo Details are in: %LOG%
pause
exit /b 1
:failed
echo Setup or app launch failed. Error details were saved to:
echo %LOG%
echo Please send the contents of setup.log for troubleshooting.
pause
exit /b 1
