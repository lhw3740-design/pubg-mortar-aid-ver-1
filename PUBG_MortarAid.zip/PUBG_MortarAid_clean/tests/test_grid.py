import unittest

import numpy as np

from models.grid import GridDetectionError, detect_grid_spacing


class GridDetectionTests(unittest.TestCase):
    def test_recovers_bright_100_pixel_grid(self):
        image = np.full((600, 800, 3), 35, dtype=np.uint8)
        image[:, ::100] = 230
        image[::100, :, :] = 230
        found = detect_grid_spacing(image)
        self.assertAlmostEqual(found.horizontal_px, 100, delta=1)
        self.assertAlmostEqual(found.vertical_px, 100, delta=1)

    def test_rejects_image_without_repeating_grid(self):
        image = np.full((400, 500, 3), 40, dtype=np.uint8)
        with self.assertRaises(GridDetectionError):
            detect_grid_spacing(image)

    def test_rejects_disagreeing_axis_scales(self):
        image = np.full((600, 800, 3), 35, dtype=np.uint8)
        image[:, ::80] = 230
        image[::120, :, :] = 230
        with self.assertRaises(GridDetectionError):
            detect_grid_spacing(image)


if __name__ == "__main__":
    unittest.main()
