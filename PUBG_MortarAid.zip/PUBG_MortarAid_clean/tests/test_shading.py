import math
import unittest

import numpy as np

from models.shading import estimate_height_delta


class ShadingTests(unittest.TestCase):
    def test_synthetic_lambertian_plane_recovers_relative_height(self):
        azimuth = 315.0
        elevation = 45.0
        albedo = 0.9
        slope = 0.2
        el = math.radians(elevation)
        horizontal = math.cos(el)
        vertical = math.sin(el)
        linear_intensity = albedo * (vertical - slope * horizontal) / math.sqrt(1 + slope * slope)
        srgb = 12.92 * linear_intensity if linear_intensity <= 0.0031308 else 1.055 * linear_intensity ** (1 / 2.4) - 0.055
        value = int(round(255 * srgb))
        image = np.full((240, 240, 3), value, dtype=np.uint8)
        ax = math.sin(math.radians(azimuth))
        ay = -math.cos(math.radians(azimuth))
        start = (120, 120)
        target = (120 + ax * 80, 120 + ay * 80)
        estimate = estimate_height_delta(image, start, target, 100, azimuth, elevation, albedo)
        self.assertAlmostEqual(estimate.height_delta_m, slope * 80, delta=1.5)
        self.assertIn("실험 검증 전", estimate.validation_status)


if __name__ == "__main__":
    unittest.main()
