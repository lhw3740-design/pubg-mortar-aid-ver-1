import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from models.ballistics import BallisticDomainError, estimate_setting
from models.terrain import GeoreferencedHeightMap, TerrainDataError


class BallisticsTests(unittest.TestCase):
    def test_level_ground_is_horizontal_range(self):
        self.assertAlmostEqual(estimate_setting(300, 0).setting_m, 300)
        self.assertAlmostEqual(estimate_setting(600, 0).setting_m, 600)

    def test_uphill_and_downhill_are_distinct_and_finite(self):
        up = estimate_setting(300, 100).setting_m
        down = estimate_setting(300, -100).setting_m
        self.assertTrue(np.isfinite(up) and np.isfinite(down))
        self.assertGreater(up, 300)
        self.assertLess(down, 300)
        self.assertAlmostEqual(up, 327.0294146, places=5)
        self.assertAlmostEqual(down, 280.4540769, places=5)

    def test_no_real_solution_rejected(self):
        with self.assertRaises(BallisticDomainError):
            estimate_setting(701, 0)


class TerrainTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        root = Path(self.temp.name)
        Image.fromarray(np.array([[0, 100], [200, 300]], dtype=np.uint16)).save(root / "height.png")
        (root / "map.json").write_text(json.dumps({
            "map_name": "synthetic", "world_width_m": 1000, "world_height_m": 1000,
            "elevation_m_per_code": 0.5, "elevation_offset_m": 10,
            "uncertainty_m": 2, "source": "synthetic test"
        }), encoding="utf-8")
        self.raster = GeoreferencedHeightMap(root / "height.png", root / "map.json")

    def tearDown(self):
        self.temp.cleanup()

    def test_bilinear_sample_and_height_delta(self):
        self.assertAlmostEqual(self.raster.sample(500, 500).elevation_m, 85)
        _, _, delta = self.raster.height_delta((0, 0), (1000, 1000))
        self.assertAlmostEqual(delta, 150)

    def test_outside_extent_rejected(self):
        with self.assertRaises(TerrainDataError):
            self.raster.sample(1001, 10)


if __name__ == "__main__":
    unittest.main()
