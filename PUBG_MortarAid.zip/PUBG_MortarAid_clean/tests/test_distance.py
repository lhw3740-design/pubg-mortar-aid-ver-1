import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pubg_map_distance import distance_meters

class DistanceTests(unittest.TestCase):
    def test_equal_pixel_lengths_equal_calibration_distance(self):
        self.assertAlmostEqual(distance_meters((0, 0), (100, 0), (25, 40), (125, 40), 100), 100)
    def test_diagonal_distance(self):
        self.assertAlmostEqual(distance_meters((0, 0), (100, 100), (0, 0), (100, 0), 100), 141.421356, places=5)
    def test_scaled_calibration(self):
        self.assertAlmostEqual(distance_meters((0, 0), (200, 0), (0, 0), (100, 0), 100), 200)

if __name__ == '__main__':
    unittest.main()

