import math
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

from PIL import Image, ImageTk
from models.ballistics import BallisticDomainError, estimate_setting
from models.grid import GridDetectionError, detect_grid_spacing


def distance_meters(start, end, cal_a, cal_b, calibration_m):
    calibration_px = math.hypot(cal_a[0] - cal_b[0], cal_a[1] - cal_b[1])
    if calibration_px <= 0 or calibration_m <= 0:
        raise ValueError("Calibration must be positive")
    return math.hypot(start[0] - end[0], start[1] - end[1]) / calibration_px * calibration_m


class MortarMapApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PUBG 지도 거리 측정기")
        self.root.geometry("1100x780")
        self.image = None
        self.photo = None
        self.scale = 1.0
        self.offset = (0, 0)
        self.player = None
        self.target = None
        self.cal_a = None
        self.cal_b = None
        self.grid_spacing = None
        self.mode = tk.StringVar(value="player")
        self.status = tk.StringVar(value="스크린샷을 열고 시작 지점과 목표 핑을 지정하세요.")
        self.result = tk.StringVar(value="수평거리: —")
        self.model_result = tk.StringVar(value="커뮤니티 탄도 추정값: —")
        self._build_ui()

    def _build_ui(self):
        bar = ttk.Frame(self.root, padding=8)
        bar.pack(fill="x")
        ttk.Button(bar, text="스크린샷 열기", command=self.open_image).pack(side="left")
        ttk.Label(bar, text="  클릭 모드:").pack(side="left")
        for label, value in (("내 위치", "player"), ("목표 핑", "target"), ("격자 기준점 A", "cal_a"), ("격자 기준점 B", "cal_b")):
            ttk.Radiobutton(bar, text=label, value=value, variable=self.mode).pack(side="left", padx=3)
        ttk.Label(bar, text="기준점 간 실제 거리(m):").pack(side="left", padx=(12, 3))
        self.cal_m = tk.StringVar(value="100")
        ttk.Entry(bar, textvariable=self.cal_m, width=8).pack(side="left")
        ttk.Button(bar, text="거리 계산", command=self.calculate).pack(side="left", padx=10)
        ttk.Button(bar, text="초기화", command=self.clear_points).pack(side="left")
        ttk.Button(bar, text="격자 자동 인식", command=self.auto_calibrate_grid).pack(side="left", padx=8)

        self.canvas = tk.Canvas(self.root, background="#202328", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=8)
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Configure>", lambda _e: self.draw())
        ttk.Label(self.root, textvariable=self.result, font=("Segoe UI", 15, "bold"), padding=(10, 8)).pack(anchor="w")
        model_bar = ttk.Frame(self.root, padding=(10, 2))
        model_bar.pack(fill="x")
        ttk.Label(model_bar, text="고도차 H (목표−발사, m; 직접 입력):").pack(side="left")
        self.height_delta = tk.StringVar(value="")
        ttk.Entry(model_bar, textvariable=self.height_delta, width=10).pack(side="left", padx=5)
        ttk.Label(model_bar, textvariable=self.model_result, foreground="#8b342c").pack(side="left", padx=8)
        ttk.Label(self.root, text="게임 지형 고도 자동조회는 데이터·좌표 정합이 없어 제공되지 않습니다. 탄도값은 커뮤니티 식의 실험 검증 전 추정입니다.", padding=(10, 2), foreground="#8b342c").pack(anchor="w")
        ttk.Label(self.root, textvariable=self.status, padding=(10, 7), wraplength=1000).pack(anchor="w")

    def open_image(self):
        path = filedialog.askopenfilename(title="PUBG 지도 스크린샷 선택", filetypes=[("이미지", "*.png *.jpg *.jpeg *.bmp *.webp"), ("모든 파일", "*.*")])
        if not path:
            return
        try:
            self.image = Image.open(path).convert("RGB")
        except Exception as exc:
            messagebox.showerror("이미지를 열 수 없음", str(exc))
            return
        self.path = Path(path)
        self.player = self.target = self.cal_a = self.cal_b = None
        self.grid_spacing = None
        self.status.set(f"{self.path.name} · {self.image.width}×{self.image.height}px · 이번 이미지에서 새로 보정하세요.")
        self.draw()

    def draw(self):
        self.canvas.delete("all")
        if self.image is None:
            self.canvas.create_text(25, 25, anchor="nw", fill="white", text="스크린샷을 열어주세요.")
            return
        cw, ch = max(self.canvas.winfo_width(), 1), max(self.canvas.winfo_height(), 1)
        self.scale = min(cw / self.image.width, ch / self.image.height)
        w, h = round(self.image.width * self.scale), round(self.image.height * self.scale)
        self.offset = ((cw - w) // 2, (ch - h) // 2)
        view = self.image.resize((w, h), Image.Resampling.LANCZOS)
        self.photo = ImageTk.PhotoImage(view)
        ox, oy = self.offset
        self.canvas.create_image(ox, oy, image=self.photo, anchor="nw")
        def xy(p): return (ox + p[0] * self.scale, oy + p[1] * self.scale)
        points = [("player", self.player, "#ffe34f", "내 위치"), ("target", self.target, "#35d8ff", "목표 핑"), ("cal_a", self.cal_a, "#7dff7a", "A"), ("cal_b", self.cal_b, "#ff7dca", "B")]
        for _, p, color, label in points:
            if p:
                x, y = xy(p)
                r = 8
                self.canvas.create_oval(x-r, y-r, x+r, y+r, outline=color, width=3)
                self.canvas.create_text(x+11, y-12, anchor="w", fill=color, text=label)
        if self.player and self.target:
            x1,y1=xy(self.player); x2,y2=xy(self.target)
            self.canvas.create_line(x1,y1,x2,y2, fill="#ff4d4d", width=2)
        if self.cal_a and self.cal_b:
            x1,y1=xy(self.cal_a); x2,y2=xy(self.cal_b)
            self.canvas.create_line(x1,y1,x2,y2, fill="#7dff7a", width=2, dash=(5,3))

    def on_click(self, event):
        if self.image is None:
            return
        ox, oy = self.offset
        x = (event.x - ox) / self.scale
        y = (event.y - oy) / self.scale
        if not (0 <= x < self.image.width and 0 <= y < self.image.height):
            return
        setattr(self, self.mode.get(), (x, y))
        if self.mode.get() in ("cal_a", "cal_b"):
            self.grid_spacing = None
        self.status.set(f"{self.mode.get()} 지점을 지정했습니다. 아이콘/핑 중심을 클릭하고, A와 B는 한 격자 간격(100m) 양 끝에 놓으세요.")
        self.draw()

    def auto_calibrate_grid(self):
        if self.image is None:
            messagebox.showinfo("이미지 필요", "먼저 PUBG 지도 스크린샷을 여세요.")
            return
        try:
            found = detect_grid_spacing(self.image)
        except GridDetectionError as exc:
            self.grid_spacing = None
            self.status.set(f"격자 자동 인식 실패: {exc}. A/B 수동 보정을 사용하세요.")
            return
        self.grid_spacing = found
        self.cal_a = self.cal_b = None
        self.status.set(
            f"격자 자동 보정 후보: 가로 {found.horizontal_px:.1f}px/100m, "
            f"세로 {found.vertical_px:.1f}px/100m · 반복 점수 "
            f"{found.confidence_x:.2f}/{found.confidence_y:.2f}. "
            "화면에서 격자와 맞는지 확인한 뒤 거리 계산을 누르세요."
        )
        self.draw()

    def calculate(self):
        if self.image is None or self.player is None or self.target is None:
            messagebox.showinfo("점 지정 필요", "이미지를 열고 내 위치와 목표 핑 중심을 클릭하세요.")
            return
        if self.grid_spacing is None and (self.cal_a is None or self.cal_b is None):
            messagebox.showinfo("축척 보정 필요", "격자선 한 칸의 양 끝점을 A와 B로 지정하세요.")
            return
        def dist(a,b): return math.hypot(a[0]-b[0], a[1]-b[1])
        if self.grid_spacing is not None:
            pixels = (self.grid_spacing.horizontal_px + self.grid_spacing.vertical_px) / 2
            meters = 100.0
            scale_note = f"자동 격자 {self.grid_spacing.horizontal_px:.1f}/{self.grid_spacing.vertical_px:.1f}px per 100m"
        else:
            try:
                meters = float(self.cal_m.get())
                if meters <= 0: raise ValueError()
            except ValueError:
                messagebox.showerror("잘못된 거리", "기준점 간 실제 거리는 0보다 큰 숫자여야 합니다.")
                return
            pixels = dist(self.cal_a, self.cal_b)
            if pixels < 2:
                messagebox.showerror("보정 실패", "기준점이 너무 가깝습니다. 더 넓은 격자 구간을 선택하세요.")
                return
            scale_note = f"수동 축척 {pixels:.1f}px / {meters:g}m"
        dpx = dist(self.player, self.target)
        value = dpx / pixels * meters
        self.result.set(f"수평 직선거리 L: {value:.0f} m    ({scale_note}, 두 점 {dpx:.1f}px)")
        height_text = self.height_delta.get().strip()
        if height_text:
            try:
                h_m = float(height_text)
                estimate = estimate_setting(value, h_m)
                self.model_result.set(f"예측 설정값: {estimate.setting_m:.0f} m — {estimate.validation_status} (커뮤니티 모델 v1)")
            except (ValueError, BallisticDomainError) as exc:
                self.model_result.set(f"예측 설정값: 산출 불가 — {exc}")
        else:
            self.model_result.set("예측 설정값: 산출 불가 — H를 입력하세요")
        self.status.set("상태: 사용자 지정 위치 + 수동 축척 보정. 점 중심 및 보정점 선택 오차가 포함되며 정량적 오차는 검증되지 않았습니다. 이미지 밝기나 음영은 고도(m)로 변환하지 않습니다.")
        self.draw()

    def clear_points(self):
        self.player = self.target = self.cal_a = self.cal_b = None
        self.grid_spacing = None
        self.result.set("수평거리: —")
        self.model_result.set("커뮤니티 탄도 추정값: —")
        self.status.set("지점과 보정을 초기화했습니다. 현재 이미지에서 다시 지정하세요.")
        self.draw()


if __name__ == "__main__":
    root = tk.Tk()
    app = MortarMapApp(root)
    root.mainloop()



