@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher (py) was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/ and enable the Python Launcher option.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating a private virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :failed
)
echo Installing or updating required packages...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :failed
echo Starting PUBG Map Distance Tool...
.venv\Scripts\python.exe pubg_map_distance.py
if errorlevel 1 goto :failed
exit /b 0
:failed
echo.
echo Setup or launch failed. Check that Python 3.10+ and internet access are available.
pause
exit /b 1
